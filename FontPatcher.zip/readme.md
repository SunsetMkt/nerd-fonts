
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 1f83dad3867d8e5120af3dfee31b5b5a6d3b97fe
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Thu Nov 16 17:51:52 2023 +0000
        
            [ci] Update FontPatcher.zip
